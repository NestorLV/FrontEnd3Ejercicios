import React from "react"

class Header extends React.Component {
    render() {
        return (
            <header>
                <h1>Perritos</h1>
                <h3>Seleccionaste: Todos</h3>
            </header>
        )
    }
}

export default Header