import React from 'react';
import Header from './Header.js';
import Botonera from './Botonera.js';
import './App.css';


class App extends React.Component {
  
  render() {
    return (
      <div class="app">
        <Header />
        <main>
          <div class="listado-perritos">
            <div class="perrito">
              <img src="https://via.placeholder.com/80" alt="" />
              <div>
                <h2>Beagle</h2>
                <small>Pequeño</small>
              </div>
            </div>
            <div class="perrito">
              <img src="https://via.placeholder.com/80" alt="" />
              <div>
                <h2>Beagle</h2>
                <small>Pequeño</small>
              </div>
            </div>
            <div class="perrito">
              <img src="https://via.placeholder.com/80" alt="" />
              <div>
                <h2>Beagle</h2>
                <small>Pequeño</small>
              </div>
            </div>
            <div class="perrito">
              <img src="https://via.placeholder.com/80" alt="" />
              <div>
                <h2>Beagle</h2>
                <small>Pequeño</small>
              </div>
            </div>
            <div class="perrito">
              <img src="https://via.placeholder.com/80" alt="" />
              <div>
                <h2>Beagle</h2>
                <small>Pequeño</small>
              </div>
            </div>
            <div class="perrito">
              <img src="https://via.placeholder.com/80" alt="" />
              <div>
                <h2>Beagle</h2>
                <small>Pequeño</small>
              </div>
            </div>
            <div class="perrito">
              <img src="https://via.placeholder.com/80" alt="" />
              <div>
                <h2>Beagle</h2>
                <small>Pequeño</small>
              </div>
            </div>
            <div class="perrito">
              <img src="https://via.placeholder.com/80" alt="" />
              <div>
                <h2>Beagle</h2>
                <small>Pequeño</small>
              </div>
            </div>
            <div class="perrito">
              <img src="https://via.placeholder.com/80" alt="" />
              <div>
                <h2>Beagle</h2>
                <small>Pequeño</small>
              </div>
            </div>
            <div class="perrito">
              <img src="https://via.placeholder.com/80" alt="" />
              <div>
                <h2>Beagle</h2>
                <small>Pequeño</small>
              </div>
            </div>
          </div>
          <Botonera />
        </main>
      </div>
    )
  }
}

export default App;